-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Feb 16, 2019 at 06:53 AM
-- Server version: 5.0.45
-- PHP Version: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `studentmarks`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `batch`
-- 

CREATE TABLE `batch` (
  `id` bigint(20) NOT NULL auto_increment,
  `version` bigint(20) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `batch`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `marksheet`
-- 

CREATE TABLE `marksheet` (
  `id` bigint(20) NOT NULL auto_increment,
  `version` bigint(20) NOT NULL,
  `marks` int(11) NOT NULL,
  `sj_id` bigint(20) NOT NULL,
  `st_id` bigint(20) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `FKC9178EB2AB82900C` (`sj_id`),
  KEY `FKC9178EB2AADB48D1` (`st_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

-- 
-- Dumping data for table `marksheet`
-- 

INSERT INTO `marksheet` (`id`, `version`, `marks`, `sj_id`, `st_id`) VALUES 
(6, 5, 30, 2, 3),
(7, 6, 39, 3, 3),
(9, 0, 70, 2, 4),
(10, 0, 70, 3, 4),
(12, 0, 45, 5, 3),
(14, 0, 66, 2, 9),
(15, 0, 76, 3, 9),
(16, 0, 77, 5, 9),
(18, 0, 70, 1, 13),
(19, 0, 75, 2, 13),
(20, 0, 69, 3, 13),
(21, 0, 80, 5, 13),
(22, 0, 78, 6, 13);

-- --------------------------------------------------------

-- 
-- Table structure for table `student`
-- 

CREATE TABLE `student` (
  `id` bigint(20) NOT NULL auto_increment,
  `version` bigint(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `batch` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `roll` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

-- 
-- Dumping data for table `student`
-- 

INSERT INTO `student` (`id`, `version`, `address`, `batch`, `email`, `image`, `name`, `phone`, `roll`) VALUES 
(3, 13, 'Chabil', '2015', 'hari@gmail.com', 'image1.jpg', 'Hari', '82930495', '3'),
(4, 7, 'Ktm', '2015', 'sita@gmail.com', 'image6.jpg', 'Sita', '192030494', '4'),
(5, 2, 'Bkt', '2015', 'rita@gmail.com', 'image9.png', 'Rita', '893939020', '5'),
(6, 1, 'Ltp', '2016', 'gita@gmail.com', 'image7.jpg', 'Gita', '857483929', '1'),
(7, 4, 'Bnp', '2016', 'krishna@gmail.com', 'image3.png', 'Krishna', '9838292929', '2'),
(8, 2, 'Bnp', '2016', 'radha@gmail.com', 'image5.png', 'Radha', '85939282', '3'),
(9, 3, 'Chitwan', '2017', 'binita@gmail.com', 'image8.jpg', 'Binita', '8485858', '1'),
(10, 1, 'Bkt', '2017', 'ram@gmail.com', 'image2.jpg', 'Ram', '3904098', '8'),
(11, 1, 'Kathmandu', '2019', 'm@gmail.com', 'image3.png', 'Milan', '989', '9'),
(12, 0, 'Bhaktapur', '2017', '', 'null', 'Nitish', '', '987682345'),
(13, 0, 'Baudha, Kathmandu', '2017', 'pdhungana@gmail.com', 'image8.jpg', 'Pratiksha Dhungana', '98765445678', '1111');

-- --------------------------------------------------------

-- 
-- Table structure for table `subject`
-- 

CREATE TABLE `subject` (
  `id` bigint(20) NOT NULL auto_increment,
  `version` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_mark` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `subject`
-- 

INSERT INTO `subject` (`id`, `version`, `name`, `total_mark`) VALUES 
(1, 2, 'Math', 100),
(2, 0, 'Science', 100),
(3, 0, 'Nepali', 100),
(5, 0, 'Opt Math', 100),
(6, 0, 'Social Studies', 100);

-- --------------------------------------------------------

-- 
-- Table structure for table `user`
-- 

CREATE TABLE `user` (
  `id` bigint(20) NOT NULL auto_increment,
  `version` bigint(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_type` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

-- 
-- Dumping data for table `user`
-- 

INSERT INTO `user` (`id`, `version`, `password`, `user_type`, `username`) VALUES 
(1, 0, 'admin', 'admin', 'admin'),
(2, 1, 'admin1', 'admin', 'admin8'),
(3, 0, 'admin2', 'admin', 'admin2'),
(4, 0, 'admin3', 'admin', 'admin3'),
(5, 0, 'admin4', 'admin', 'admin4'),
(6, 0, 'nitish', 'HR', 'nitish'),
(7, 0, 'admin', 'admin', 'admin999');

-- 
-- Constraints for dumped tables
-- 

-- 
-- Constraints for table `marksheet`
-- 
ALTER TABLE `marksheet`
  ADD CONSTRAINT `FKC9178EB2AADB48D1` FOREIGN KEY (`st_id`) REFERENCES `student` (`id`),
  ADD CONSTRAINT `FKC9178EB2AB82900C` FOREIGN KEY (`sj_id`) REFERENCES `subject` (`id`);

-- 
-- Procedures
-- 
DELIMITER $$
-- 
CREATE DEFINER=`root`@`localhost` PROCEDURE `result`(
		IN batch CHAR(20)
	)
BEGIN
		Set @zzbatch = batch;
		Set @where_clause = NULL;
		
		CASE WHEN @zzbatch = '' THEN SET @where_clause = '';
		ELSE SET @where_clause = CONCAT('WHERE Batch = ''',@zzbatch, '''');
		END CASE;
		
		SET @SQL = NULL;
		SET @zzSQL = NULL;
		SELECT GROUP_CONCAT(DISTINCT CONCAT('SUM(CASE WHEN sj.name = ''', sj.name, ''' THEN m.marks ELSE NULL END) AS ', REPLACE(sj.name, ' ', '')))
		INTO @SQL
		FROM SUBJECT sj;
		SET @zzSQL = CONCAT('SELECT * FROM
				(SELECT s.name as StudentName
				, s.batch as Batch
				, s.email as Email
					, s.roll as RollNo
					, a.*
				FROM (
				SELECT m.st_id, ', @SQL, '
				FROM SUBJECT sj
				INNER JOIN marksheet m
				ON sj.id = m.sj_id
				GROUP BY m.st_id) a
				INNER JOIN student s 
				ON a.st_id = s.id
				) b INNER JOIN (
				SELECT SUM(m.marks) AS total_mark_obtained
					, SUM(s.total_mark) AS total_mark
					, SUM(m.marks)/SUM(s.total_mark)*100 AS percentage
					, m.st_id
				FROM marksheet m
				INNER JOIN SUBJECT s
				ON m.sj_id = s.id
				GROUP BY m.st_id
				) c
				ON b.st_id = c.st_id ',
				@where_clause
				,' ORDER BY b.st_id');
		PREPARE stmt FROM @zzSQL;
		EXECUTE stmt;
		DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `zzresult`(
		IN batch CHAR(20)
	)
BEGIN
		SET @where_clause = NULL;
		
		CASE WHEN @batch = '' THEN SET @where_clause = '';
		ELSE SET @where_clause = CONCAT('WHERE Batch = ''',@batch, '');
		END CASE;
	
END$$

-- 
DELIMITER ;
-- 
